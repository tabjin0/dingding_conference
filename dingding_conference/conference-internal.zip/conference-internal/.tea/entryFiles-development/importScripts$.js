if(!self.Map || !self.Set) {
    importScripts('https://gw.alipayobjects.com/as/g/appx_release/deps/1.0.0/es6-set-map.js');
     }
     