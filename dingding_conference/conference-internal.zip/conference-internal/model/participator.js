/**
 * 选择人员模型
 */

class Participator {

}

export {
    Participator
}