// /**
//  * 通知模型
//  */
// import {Http} from "../utils/http";
//
// class Notice {
//     static async getReadResult(mid) {
//         const readResult = await Http.request({
//             url: `5db166f379eeb`,
//             data: {
//                 mid: mid
//             }
//         });
//         return readResult;
//     }
// }
//
// export {
//     Notice
// }